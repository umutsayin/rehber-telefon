﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace telrehber
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            btn_guncelle.Visible = true;

            SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-8G4LNPC\\MSSQLSERVER2; Initial Catalog=rehber; Integrated Security=True ; ");
            baglanti.Open();

            SqlCommand cmdkaydet = new SqlCommand("Update rehber Set Ad='"+txt_ad.Text+"'where Ad = '"+dataGridView1.CurrentRow.Cells[0].Value.ToString()+"'",baglanti);

            cmdkaydet.ExecuteNonQuery();
            Form1_Load(sender, e);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-8G4LNPC\\MSSQLSERVER2; Initial Catalog=rehber; Integrated Security=True ; ");
            baglanti.Open();

            SqlCommand cmdara = new SqlCommand("Select * from rehber where Ad like '%"+txt_ara.Text+"%'",baglanti);
            SqlDataReader dr = cmdara.ExecuteReader();
            
            DataTable dt = new DataTable();
            dt.Load(dr);

            dataGridView1.DataSource = dt;


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btn_kaydet.Visible = false;


            SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-8G4LNPC\\MSSQLSERVER2; Initial Catalog=rehber; Integrated Security=True ; ");
            baglanti.Open();
            SqlCommand cmdveri = new SqlCommand("Select * from rehber", baglanti);
           
            SqlDataReader dr = cmdveri.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Load(dr);

            dataGridView1.DataSource = dt;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-8G4LNPC\\MSSQLSERVER2; Initial Catalog=rehber; Integrated Security=True; ");
            baglanti.Open();

            SqlCommand cmdekle = new SqlCommand("insert into Rehber (Ad,Soyad,Firma,Telefon,Mail ) Values ('" + txt_ad.Text + "', '" + txt_soyad.Text + "', '" + txt_firma.Text + "', '" + txt_tel.Text + "', '" + txt_mail.Text + "')",baglanti );
            cmdekle.ExecuteNonQuery();
            txt_ad.Text = "";
            txt_soyad.Text = "";
            txt_firma.Text = "";
            txt_tel.Text = "";
            txt_mail.Text = "";
            Form1_Load(sender, e);


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_sil_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-8G4LNPC\\MSSQLSERVER2; Initial Catalog=rehber; Integrated Security=True; ");
            baglanti.Open();

            SqlCommand cmdsil = new SqlCommand("delete from rehber where Telefon='" + dataGridView1.CurrentRow.Cells[0].Value.ToString() + "'", baglanti);

            cmdsil.ExecuteNonQuery();
            Form1_Load(sender, e);




        }

        private void button3_Click(object sender, EventArgs e)
        {
            btn_kaydet.Visible = true;
            btn_guncelle.Visible = false;
            
            SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-8G4LNPC\\MSSQLSERVER2; Initial Catalog=rehber; Integrated Security=True; ");
            baglanti.Open();

            SqlCommand cmdguncelle = new SqlCommand("Select * from rehber where Ad='" + dataGridView1.CurrentRow.Cells[0].Value.ToString()+"'" , baglanti);

            SqlDataReader dr = cmdguncelle.ExecuteReader();

            DataTable dt = new DataTable();

            dt.Load(dr);
             
            DataRow satır= dt.Rows [0];

            txt_ad.Text = satır["Ad"].ToString();


        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-8G4LNPC\\MSSQLSERVER2; Initial Catalog=rehber; Integrated Security=True ; ");
            baglanti.Open();

            SqlCommand cmdaraa = new SqlCommand("Select * from rehber where Ad like '%" + txt_araa.Text + "%'", baglanti);
            SqlDataReader dr = cmdaraa.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Load(dr);

            dataGridView1.DataSource = dt;
        }
    }
}
